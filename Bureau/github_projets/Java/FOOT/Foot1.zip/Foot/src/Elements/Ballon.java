package Elements;

public class Ballon {
	public static double x;
	public static double y;
	public static double vX;
	public static double vY;
	
	public Ballon(int x, int y){
		Ballon.x=x;
		Ballon.y=y;
	}
	
	public static void passe(double theta, double v){
		 vX = v*Math.cos(theta);
		 vY = v*Math.sin(theta);
	}
	
	public boolean but(int camp){
		if (camp==Terrain.gauche) return ((Ballon.x<0)&&(Ballon.y>Terrain.dimY/2-Terrain.lBut/2)&&(Ballon.y<Terrain.dimY/2+Terrain.lBut/2));
		else return ((Ballon.y<0)&&(Ballon.y>Terrain.dimY/2-Terrain.lBut/2)&&(Ballon.y<Terrain.dimY/2+Terrain.lBut/2));
	}
	
	public boolean sortieSM(){
		return ((Ballon.x>Terrain.dimX)||(Ballon.x<0))&&!but(0)&&!but(1);
	}
	
	public boolean sortieT(){
		return (Ballon.y<0)||(Ballon.y>Terrain.dimY);
	}
	
	public void touche(int camp){
		vX=0;
		vY=0;
	}
	
	public void sixMetres(int camp){
		vX=0; vY=0;
		Ballon.y=Terrain.dimY/2;
		if (camp==Terrain.gauche) Ballon.x=6;
		else Ballon.x=Terrain.dimX-6;
	}
	
	public void etatSuivant(double dt){
		double theta;
		if (vX>1){
		theta=Math.atan(vY/vX);
		if (vX<0) theta+=Math.PI;
		if (Math.abs(vX)-Math.abs(Terrain.ralentissement*dt*Math.cos(theta))<0) vX=0;
		else vX+=Terrain.ralentissement*dt*Math.cos(theta);
		if (Math.abs(vY)-Math.abs(Terrain.ralentissement*dt*Math.sin(theta))<0) vY=0;
		else vY+=Terrain.ralentissement*dt*Math.sin(theta);
		}
		Ballon.x+=vX*dt;
		Ballon.y+=vY*dt;
		if (sortieSM()){
			sixMetres(0);
		}
		if (sortieT()){
			touche(0);
		}
		if (but(0)){
			System.out.println("La gauche a marqu� !!");
		}
		if (but(1)){
			System.out.println("La droite a marqu� !!");
		}
	}
	
	
	
}
