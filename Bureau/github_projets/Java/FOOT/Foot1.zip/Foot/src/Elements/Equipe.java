package Elements;

import java.util.ArrayList;

public class Equipe {
	public ArrayList<Joueur> joueurs = new ArrayList<Joueur>();
	public static int nbJoueurs = 4;
	public Equipe(int camp){
		int i;
		for (i=0;i<nbJoueurs;i++){
			if (camp==Terrain.gauche) joueurs.add(new Joueur(Terrain.dimX*i/nbJoueurs/2,Terrain.dimY/2));
			if (camp==Terrain.droite) joueurs.add(new Joueur(Terrain.dimX-Terrain.dimX*i/nbJoueurs/2,Terrain.dimY/2));
		}
	}
	public void etatSuivant(double dt){
		int i;
		for (i=0;i<Equipe.nbJoueurs;i++){
			joueurs.get(i).etatSuivant(dt);
		}
	}
}
