package jeux;
import java.awt.Color;

import Elements.*;

import graph.Pan;
import graph.Screen;
import contr�le.Jcontr�le;

public abstract class test2 {

	public static void main(String[] args) {
		Jeux jeux = new Jeux();
		jeux.lancerjeux();
	}

}
