package graph;

import Elements.Terrain;

public class FPlay {

	public static void main(String[] args) {
		Screen s0 = new Screen();
		//s0.setContentPane(new Pan());
        
	}

}
