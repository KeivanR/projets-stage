package graph;
import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Screen extends JFrame {

	JPanel pan = new JPanel();

	public Screen()
	{
		        
	    //D�finit un titre pour notre fen�tre
	    this.setTitle("Screen");
	    //D�finit sa taille : 400 pixels de large et 100 pixels de haut
	    this.setSize(1200,600);
	    //Nous demandons maintenant � notre objet de se positionner au centre
	    this.setLocationRelativeTo(null);
	    //Termine le processus lorsqu'on clique sur la croix rouge
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    //Et enfin, la rendre visible        
	    this.setVisible(true);
       //couleur du fond 
	    pan.setBackground(Color.DARK_GRAY);
	   //on applique � notre �cran
	    
	    }
	
	public void modifPan(Pan pan){
		
		this.pan=pan;
		this.setContentPane(pan);
	}
	
	public JPanel getPan(){
		return pan;
		
	}
	
	
	 public void refresh(){
		    
		      pan.repaint();  
		      try {
		        Thread.sleep(10);
		      } catch (InterruptedException e) {
		        e.printStackTrace();
		      }
		     
		}
}
