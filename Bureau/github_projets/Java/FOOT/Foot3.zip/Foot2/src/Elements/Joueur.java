package Elements;

public class Joueur {
	public double x;
	public double y;
	public double vMax=100;
	public double vX;
	public double vY;
	public boolean gardeBallon=false;
	Joueur(int x, int y){
		this.x=x;
		this.y=y;
	}
	
	public void accelerer(double theta, double a, double dt){
		double wX = vX+a*dt*Math.cos(theta);
		double wY = vY+a*dt*Math.sin(theta);
		if (Math.sqrt((Math.pow(wX,2)+Math.pow(wY,2)))<=vMax) {
			vX=wX;
			vY=wY;
		}
	}
	
	public boolean possedeBallon(){
		return ((Math.abs(Ballon.x-x)<2)&&(Math.abs(Ballon.y-y)<2));
	}
	
	public void passer(double theta, double v){
		if (possedeBallon()){
		Ballon.x=x+3*Math.cos(theta);
		Ballon.y=y+3*Math.sin(theta);
		Ballon.passe(theta,v);
		}
	}
	
	public void etatSuivant(double dt){
		if (x+vX*dt<=Terrain.dimX) this.x+=vX*dt;
		if (y+vY*dt<=Terrain.dimY) this.y+=vY*dt;
		if (possedeBallon()) {
			Ballon.vX=0;
			Ballon.vY=0;
			Ballon.x=x;
			Ballon.y=y;
		}
	}
	
	public double getx()
	{
		return x;
	}
	
	public double gety()
	{
		return y;
	}
	
	public double getvX()
	{
		return vX;
	}
	
	public double getvY()
	{
		return vY;
	}
	
	
}
