package contr�le;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import graph.Pan;
import graph.Screen;

public class Jcontr�le implements KeyListener {
    private boolean touchea = false;
    private boolean toucheSPACE =false;
    int nbplayers=4;
    int joueur=0;
   
   
    
    public void keyTyped(KeyEvent e) {
     
    if(touchea == true) {}
    if(e.getKeyCode()==KeyEvent.VK_SPACE){}
    	
    
   
     
        try { Thread.sleep(1); }
        catch (InterruptedException ie) { ie.printStackTrace(); }
    }
    
 
    public void keyPressed(KeyEvent e) {
     
    if (e.getKeyChar()=='a') 
    touchea = true; 
    if(e.getKeyCode()==KeyEvent.VK_SPACE){
    	toucheSPACE=true;
        	joueur=(joueur+1)%nbplayers;
        	
    System.out.println(joueur);
    }
    
    }
     
    public void keyReleased(KeyEvent e) {
 
    if (e.getKeyChar()=='a') 
    touchea = false; 
    if(e.getKeyCode()==KeyEvent.VK_SPACE){
    	toucheSPACE=false;
    }
    	
    
    }
    
    
    public  int getjoueur()
    {
    	return joueur;
    }
    
    }