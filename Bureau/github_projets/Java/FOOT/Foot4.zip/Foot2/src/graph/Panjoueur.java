package graph;
import java.awt.Graphics;
import javax.swing.JPanel;
import java.awt.*;
public class Panjoueur extends JPanel { 
  public void paintComponent(Graphics g){
	  int t = 2;
    //Vous verrez cette phrase chaque fois que la m�thode sera invoqu�e
    System.out.println("Je suis ex�cut�e !"); 
    Graphics2D g2d = (Graphics2D)g;    
    
    
    g2d.fillOval(235+170, 115+50, 130, 130);
  
  }              
  
}