package Elements;

import graph.Screen;

public class Joueur {
	public double x;
	public double y;
	public double vMax=300;
	public double vX;
	public double vY;
	public double a=200000;
	public double d�c�l�ration=-20000;
	public double theta;
	Joueur(int x, int y){
		this.x=x;
		this.y=y;
	}
	
	public void accelerer(double theta){
		double wX = vX+a*Screen.dt*Math.cos(theta);
		double wY = vY+a*Screen.dt*Math.sin(theta);
		if (Math.sqrt((Math.pow(wX,2)+Math.pow(wY,2)))<=vMax) {
			vX=wX;
			vY=wY;
		}
	}
	
	public boolean possedeBallon(){
		return ((Math.abs(Ballon.x-x)<2)&&(Math.abs(Ballon.y-y)<2));
	}
	
	public void passer(double theta, double v){
		if (possedeBallon()){
		Ballon.x=x+3*Math.cos(theta);
		Ballon.y=y+3*Math.sin(theta);
		Ballon.passe(theta,v);
		}
	}
	
	public void etatSuivant(){
		if (Math.abs(vX)-Math.abs(d�c�l�ration*Screen.dt*Math.cos(getDir()))<0) vX=0;
		else vX+=d�c�l�ration*Screen.dt*Math.cos(getDir());
		if (Math.abs(vY)-Math.abs(d�c�l�ration*Screen.dt*Math.sin(getDir()))<0) vY=0;
		else vY+=d�c�l�ration*Screen.dt*Math.sin(getDir());
		
		
		if (x+vX*Screen.dt<=Terrain.dimX) this.x+=vX*Screen.dt;
		if (y+vY*Screen.dt<=Terrain.dimY) this.y+=vY*Screen.dt;
		if (possedeBallon()) {
			Ballon.vX=0;
			Ballon.vY=0;
			Ballon.x=x;
			Ballon.y=y;
		}
	}
	
	public double getx()
	{
		return x;
	}
	
	public double gety()
	{
		return y;
	}
	
	public double getvX()
	{
		return vX;
	}
	
	public double getvY()
	{
		return vY;
	}
	
	public double getDir(){
		if (Math.abs(vX)>0.01) theta=Math.atan(vY/vX);
		else {
			 if (vY<0) theta=-Math.PI/2;
			 else if (vY>0) theta=Math.PI/2;
			 
		}
		if (vX<0) theta+=Math.PI;
		return theta;
	}
	
	public double distBallon(){
		return Math.sqrt((x-Ballon.x)*(x-Ballon.x)+(y-Ballon.y)*(y-Ballon.y));
	}
	
}
