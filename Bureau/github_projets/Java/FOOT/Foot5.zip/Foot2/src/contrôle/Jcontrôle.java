package contr�le;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import Elements.Equipe;
import graph.Pan;
import graph.Screen;

public class Jcontr�le implements KeyListener {
    int puissance=0;
    int nbplayers=4;
    int joueur=0;
    boolean down,up,right,left;
    Equipe equipe;
   
    
   public Jcontr�le(Equipe equipe){
	   this.equipe=equipe;
   }
    
    public void keyTyped(KeyEvent e) {
       
    }
    
 
    public void keyPressed(KeyEvent e) {
    if(e.getKeyCode()==KeyEvent.VK_SPACE){
        	setJoueur();
        	
    System.out.println(joueur);
    }
    
    if(e.getKeyCode()==KeyEvent.VK_UP){
    	up=true;
    	
    	//if(e.getKeyCode()==KeyEvent.VK_A) equipe.joueurs.get(joueur).passer(-Math.PI/2,puissance);
    }
    if(e.getKeyCode()==KeyEvent.VK_DOWN){
    	down=true;
    	
    	//if(e.getKeyCode()==KeyEvent.VK_A) equipe.joueurs.get(joueur).passer(Math.PI/2,puissance);
    }
    if(e.getKeyCode()==KeyEvent.VK_RIGHT){
    	right=true;
    	
    	//if(e.getKeyCode()==KeyEvent.VK_A) equipe.joueurs.get(joueur).passer(0,puissance);
    }
    if(e.getKeyCode()==KeyEvent.VK_LEFT){
    	left=true;
    	
    	//if(e.getKeyCode()==KeyEvent.VK_A) equipe.joueurs.get(joueur).passer(Math.PI,puissance);
    }
    if(e.getKeyCode()==KeyEvent.VK_A){
    	
    	puissance+=200;
    }
    }
     
    public void keyReleased(KeyEvent e) {
    	  if (arrow(e)){
    	    	if(e.getKeyCode()==KeyEvent.VK_UP){
    	    		up=false;
    	        }
    	        if(e.getKeyCode()==KeyEvent.VK_DOWN){
    	        	down=false;
    	        }
    	        if(e.getKeyCode()==KeyEvent.VK_RIGHT){
    	        	
    	        	right=false;
    	        }
    	        if(e.getKeyCode()==KeyEvent.VK_LEFT){
    	        	left=false;
    	        }
    		}
    if (e.getKeyCode()==KeyEvent.VK_A){ 
    	System.out.println("hep");
	if (arrow(e)){
    	if(e.getKeyCode()==KeyEvent.VK_UP){
    		up=false;
    		equipe.joueurs.get(joueur).passer(-Math.PI/2,puissance);
        }
        if(e.getKeyCode()==KeyEvent.VK_DOWN){
        	down=false;
        	equipe.joueurs.get(joueur).passer(Math.PI/2,puissance);
        }
        if(e.getKeyCode()==KeyEvent.VK_RIGHT){
        	
        	right=false;
        	equipe.joueurs.get(joueur).passer(0,puissance);
        }
        if(e.getKeyCode()==KeyEvent.VK_LEFT){
        	left=false;
        	equipe.joueurs.get(joueur).passer(Math.PI,puissance);
        }
	}
	else equipe.joueurs.get(joueur).passer(equipe.joueurs.get(joueur).getDir(),puissance);
    puissance=0;
    }
    	
    
    }
    
    public void accelJoueur(){
    	if (up) equipe.joueurs.get(joueur).accelerer(-Math.PI/2);
    	if (down) equipe.joueurs.get(joueur).accelerer(Math.PI/2);
    	if (right) equipe.joueurs.get(joueur).accelerer(0);
    	if (left) equipe.joueurs.get(joueur).accelerer(Math.PI);
    }
    
    
    public  int getjoueur()
    {
    	return joueur;
    }
    
    public boolean arrow(KeyEvent e){
    	return (e.getKeyCode()==KeyEvent.VK_LEFT)||(e.getKeyCode()==KeyEvent.VK_DOWN)
    		||(e.getKeyCode()==KeyEvent.VK_RIGHT)||(e.getKeyCode()==KeyEvent.VK_UP);
    }
    
    public void setJoueur(){
    	joueur=equipe.joueurBallon();
    }
    
    }