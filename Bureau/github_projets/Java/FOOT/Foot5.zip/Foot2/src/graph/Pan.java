package graph;
import java.awt.Graphics;
import javax.swing.JPanel;

import Elements.*;

import java.awt.*;



public class Pan extends JPanel { 
	
	
	Equipe equipe1;
	Equipe equipe2;
	Ballon ballon;
	int equipeacontrol�e;
	int joueuracontrol�e;
	public Pan(Equipe equipe1, Equipe equipe2, Ballon ballon ,int equipeacontrol�e, int j)
	{
		
		this.equipe1=equipe1;
		this.equipe2=equipe2;
		this.ballon=ballon;
		this.joueuracontrol�e=j;
		equipeacontrol�e=1;
		
	}
	public void updatejoueurcontrol�e(int joueur)
	{
		this.joueuracontrol�e=joueur;
	}
  public void paintComponent(Graphics g){
	  int t = 2; //Largeur des bandes du terrain
	  int u= 8; //taille des joueurs
	  
    //Vous verrez cette phrase chaque fois que la m�thode sera invoqu�e
    Graphics2D g2d = (Graphics2D)g;    
    
    GradientPaint gp = new GradientPaint(0, 0, new Color(46,191,94), 25,0, new Color(9,168,59), true);                
    GradientPaint gp2 = new GradientPaint(0, 0, new Color(/*0*/255,255,255), 0,0, new Color(0,0,0), true);
    g2d.setPaint(gp);
    g2d.fillRoundRect(170, 50, 600, 360, 10, 10);
    g2d.setPaint(gp2);
    //g2d.fillRect(468, 50, 4, 360);
    g2d.fillOval(235+170, 115+50, 130, 130);
    g2d.setPaint(gp);
    g2d.fillOval(235+170+t, 115+50+t, 130-2*t, 130-2*t);
    g2d.setPaint(gp2);   
    g2d.fillRect(468, 50, t, 360);
    g2d.fillRect(170, 50, t, 360);
    g2d.fillRect(170+600-t, 50, t, 360);
    g2d.fillRect(170, 50, 600, t);
    //Surface de r�paration gauche
    g2d.fillRect(170, 50+60, 140, t);
    g2d.fillRect(170+140-t,50+60 , t, 240);
    g2d.fillRect(170, 50+360-60, 140, t);
    
    //6 m de droite 
    
    g2d.fillRect(170, 50+120, 50, t);
    g2d.fillRect(170+50-t,50+120, t,120);
    g2d.fillRect(170, 50+360-120, 50, t);
    
    
    
    //Surface de r�paration droite 
     g2d.fillRect(170+600-140-t, 50+60, 140, t);
     g2d.fillRect(170+600-140-t,50+60 , t, 240);
      g2d.fillRect(170+600-140-t, 50+360-60, 140, t);
    
    //6 m gauche
      g2d.fillRect(170+600-50, 50+120, 50, t);
      g2d.fillRect(170-t+600-50,50+120, t,120);
      g2d.fillRect(170+600-50, 50+360-120, 50, t);
   
      for(int i=0;i<equipe1.joueurs.size();i++)
      {   
          if(this.joueuracontrol�e!=i){
          g2d.setPaint(new Color(255,255,255));
    	  
          Integer I =(int) (170+Math.floor(6*(equipe1.joueurs.get(i).getx())-u/2));
    	  Integer J =(int) (50+Math.floor(6*(equipe1.joueurs.get(i).gety())-u/2));
    	  g2d.fillOval(I,J , u, u);
          }
          else
          {
        	  g2d.setPaint(new Color(0,0,0));
        	  
              Integer I =(int) (170+Math.floor(6*(equipe1.joueurs.get(i).getx())-u/2));
        	  Integer J =(int) (50+Math.floor(6*(equipe1.joueurs.get(i).gety())-u/2));
        	  g2d.fillOval(I,J , u, u);
        	  
        	  g2d.setPaint(new Color(255,255,255));
        	  
               I =(int) (170+Math.floor(6*(equipe1.joueurs.get(i).getx())-u/2));
        	   J =(int) (50+Math.floor(6*(equipe1.joueurs.get(i).gety())-u/2));
        	  g2d.fillOval(I+1,J+1 , u-2, u-2); 
          }
      }
      for(int i=0;i<equipe2.joueurs.size();i++)
      {
    	  g2d.setPaint(new Color(0,0,255));
    	  
    	  Integer I =(int) (170+Math.floor(6*(equipe2.joueurs.get(i).getx())-u/2));
    	  Integer J =(int) (50+Math.floor(6*(equipe2.joueurs.get(i).gety())-u/2));
    	  g2d.fillOval(I,J , u, u);
      }
      //Le ballon
      g2d.setPaint(new Color(255,0,0));
	  
      Integer I =(int) (170+Math.floor(6*(ballon.getx())-(u-1)/2));
	  Integer J =(int) (50+Math.floor(6*(ballon.gety())-(u-1)/2));
	  g2d.fillOval(I,J , u-1, u-1);

  }              
  
  public void refreshplayerposition(Equipe equipe1, Equipe equipe2, Ballon ballon)
  {
		this.equipe1=equipe1;
		this.equipe2=equipe2;
		this.ballon=ballon;
  }
  
}