import Elements.*;

import graph.Pan;
import graph.Screen;
import contr�le.Jcontr�le;

public abstract class test2 {

	public static void main(String[] args) {
		double t=0, i=0;
		new Terrain(100,60,8,-600);
		Ballon ball = new Ballon((int)Terrain.dimX/2,(int)Terrain.dimY/2);
		Equipe equipe1 = new Equipe(Terrain.gauche), equipe2 = new Equipe(Terrain.droite);
		
		Screen s0 = new Screen(equipe1);
		
		s0.modifPan(new Pan(equipe1,equipe2,ball,1,s0.getjccontr�le().getjoueur()));
		while(!ball.but(Terrain.droite)){
			
	     s0.updatejoueurcontrol�e();
	     
	     //Tout ce que je veux faire
	     
	     
	     //s0.getjccontr�le().getjoueur();
		((Pan) s0.getPan()).refreshplayerposition(equipe1,equipe2,ball);
		s0.refresh();
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		equipe1.etatSuivant();
		equipe2.etatSuivant();
		ball.etatSuivant();
		t+=Screen.dt;
		}
		/*for (i=0;i<Equipe.nbJoueurs;i++){
		System.out.println(equipe1.joueurs.get(i).x+","+equipe1.joueurs.get(i).y+"\n");
		}
		for (i=0;i<Equipe.nbJoueurs;i++){
		System.out.println(equipe2.joueurs.get(i).x+","+equipe2.joueurs.get(i).y+"\n");
		}*/
		/*while (t<1){
			System.out.println("Ballon : "+Ballon.x+","+Ballon.y+";"+Ballon.vX+","+Ballon.vY);
			System.out.println("Joueur : "+equipe1.joueurs.get(3).x+","+equipe1.joueurs.get(3).y+"\n");
			equipe1.joueurs.get(3).accelerer(0,2000,dt);
			//equipe1.joueurs.get(2).accelerer(Math.PI/6,5000,dt);
			if (equipe1.joueurs.get(3).possedeBallon()) {
				i++;
				if (i>50) equipe1.joueurs.get(3).passer(Math.PI+30, 150);
			}
			//if (equipe1.joueurs.get(2).possedeBallon()) {
			equipe1.etatSuivant(dt);
			equipe2.etatSuivant(dt);
			ball.etatSuivant(dt);
			
			t+=dt;
			((Pan) s0.getPan()).refreshplayerposition(equipe1,equipe2,ball);
			s0.refresh();
		}*/
	}

}
