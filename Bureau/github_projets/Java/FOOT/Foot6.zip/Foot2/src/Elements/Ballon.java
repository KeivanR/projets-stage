package Elements;

import graph.Screen;

public class Ballon {
	public static double x;
	public static double y;
	public static double vX;
	public static double vY;
	public static boolean passe=false;
	
	public Ballon(double x, double y){
		Ballon.x=x;
		Ballon.y=y;
	}
	
	public static void passe(double theta, double v){
		 vX =  v*Math.cos(theta);
		 vY =  v*Math.sin(theta);
		 passe=true;
	}
	
	public boolean but(int camp){
		if (camp==Terrain.gauche) return ((Ballon.x<1)&&(Ballon.y>Terrain.dimY/2-Terrain.lBut/2)&&(Ballon.y<Terrain.dimY/2+Terrain.lBut/2));
		else return ((Ballon.x>Terrain.dimX-1)&&(Ballon.y>Terrain.dimY/2-Terrain.lBut/2)&&(Ballon.y<Terrain.dimY/2+Terrain.lBut/2));
	}
	public boolean sortieSM(){
		return sortieSM(Terrain.gauche)||sortieSM(Terrain.droite);
	}
	public boolean sortieSM(int camp){
		if (camp==Terrain.gauche) return ((Ballon.x<1)&&!but(Terrain.gauche));
		else return ((Ballon.x>Terrain.dimX-1)&&!but(Terrain.droite));
	}
	
	public boolean sortieT(){
		return (Ballon.y<0)||(Ballon.y>Terrain.dimY);
	}
	
	public void touche(double camp){
		vX=0;
		vY=0;
	}
	
	public void sixMetres(double camp){
		vX=0; vY=0;
		Ballon.y=Terrain.dimY/2;
		if (camp==Terrain.gauche) Ballon.x=6;
		else Ballon.x=Terrain.dimX-6;
	}
	
	public void etatSuivant(){
		if (Math.abs(vX)-Math.abs(Terrain.ralentissement*Screen.dt*Math.cos(getDir()))<0) vX=0;
		else vX+=Terrain.ralentissement*Screen.dt*Math.cos(getDir());
		if (Math.abs(vY)-Math.abs(Terrain.ralentissement*Screen.dt*Math.sin(getDir()))<0) vY=0;
		else vY+=Terrain.ralentissement*Screen.dt*Math.sin(getDir());
		Ballon.x+=vX*Screen.dt;
		Ballon.y+=vY*Screen.dt;
		if (sortieSM()){
			if (sortieSM(Terrain.gauche)) sixMetres(Terrain.gauche);
			else sixMetres(Terrain.droite);
		}
		if (sortieT()){
			touche(0);
		}
		if (but(Terrain.gauche)){
			System.out.println("La droite a marqu� !!");
		}
		if (but(Terrain.droite)){
			System.out.println("La gauche a marqu� !!");
		}
	}
	
	//Ajout accesseurs
	
	public double getx()
	{
		return x;
	}
	
	public double gety()
	{
		return y;
	}
	
	public static double getv()
	{
		return Math.sqrt(vX*vX+vY*vY);
	}
	
	public double getvY()
	{
		return vY;
	}
	
	public static double getDir(){
		double theta;
		if (Math.abs(vX)>0.01) theta=Math.atan(vY/vX);
		else {
			 if (vY<0) theta=-Math.PI/2;
			 else theta=Math.PI/2;
		}
		if (vX<0) theta+=Math.PI;
		return theta;
	}
}
