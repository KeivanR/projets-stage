package contr�le;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import Elements.Ballon;
import Elements.Equipe;
import graph.Pan;
import graph.Screen;

public class Jcontr�le implements KeyListener {
    int puissance=0;
    int nbplayers=4;
    int joueur=0;
    boolean down,up,right,left;
    Equipe equipe;
   
    
   public Jcontr�le(Equipe equipe){
	   this.equipe=equipe;
   }
    
    public void keyTyped(KeyEvent e) {
       
    }
    
 
    public void keyPressed(KeyEvent e) {
    if(e.getKeyCode()==KeyEvent.VK_SPACE){
    	System.out.println("lololol");
    	equipe.joueurs.get(joueur).arret();
		equipe.joueurs.get(joueur).accelerer=false;
    	joueur=equipe.joueurBallon();
    }
    
    if(e.getKeyCode()==KeyEvent.VK_UP){
    	up=true;
    	
    	//if(e.getKeyCode()==KeyEvent.VK_A) equipe.joueurs.get(joueur).passer(-Math.PI/2,puissance);
    }
    if(e.getKeyCode()==KeyEvent.VK_DOWN){
    	down=true;
    	
    	//if(e.getKeyCode()==KeyEvent.VK_A) equipe.joueurs.get(joueur).passer(Math.PI/2,puissance);
    }
    if(e.getKeyCode()==KeyEvent.VK_RIGHT){
    	right=true;
    	
    	//if(e.getKeyCode()==KeyEvent.VK_A) equipe.joueurs.get(joueur).passer(0,puissance);
    }
    if(e.getKeyCode()==KeyEvent.VK_LEFT){
    	left=true;
    	
    	//if(e.getKeyCode()==KeyEvent.VK_A) equipe.joueurs.get(joueur).passer(Math.PI,puissance);
    }
    if(e.getKeyCode()==KeyEvent.VK_A){
    	
    	puissance+=200;
    }
    
if(e.getKeyCode()==KeyEvent.VK_E){
    	
    	equipe.joueurs.get(joueur).accelerer=true;
    }
    
    }
     
    public void keyReleased(KeyEvent e) {
    	  if (arrow(e)){
    	    	if(e.getKeyCode()==KeyEvent.VK_UP){
    	    		up=false;
    	        }
    	        if(e.getKeyCode()==KeyEvent.VK_DOWN){
    	        	down=false;
    	        }
    	        if(e.getKeyCode()==KeyEvent.VK_RIGHT){
    	        	
    	        	right=false;
    	        }
    	        if(e.getKeyCode()==KeyEvent.VK_LEFT){
    	        	left=false;
    	        }
    		}
    	  
    	  if(e.getKeyCode()==KeyEvent.VK_E){
    	    	
    	    	equipe.joueurs.get(joueur).accelerer=false;
    	    }
    	  
    if (e.getKeyCode()==KeyEvent.VK_A){ 
	if (arrow(e)){
    	if(e.getKeyCode()==KeyEvent.VK_UP){
    		up=false;
    		equipe.joueurs.get(joueur).passer(-Math.PI/2,puissance);
        }
        if(e.getKeyCode()==KeyEvent.VK_DOWN){
        	down=false;
        	equipe.joueurs.get(joueur).passer(Math.PI/2,puissance);
        }
        if(e.getKeyCode()==KeyEvent.VK_RIGHT){
        	
        	right=false;
        	equipe.joueurs.get(joueur).passer(0,puissance);
        }
        if(e.getKeyCode()==KeyEvent.VK_LEFT){
        	left=false;
        	equipe.joueurs.get(joueur).passer(Math.PI,puissance);
        }
	}
	else equipe.joueurs.get(joueur).passer(equipe.joueurs.get(joueur).getDir(),puissance);
    puissance=0;
    }
    	
    
    }
    
    public void accelJoueur(){
    	if ((up)||(down)||(left)||(right)){
	    	if (up) equipe.joueurs.get(joueur).courrir(-Math.PI/2); 
	    	if (down) equipe.joueurs.get(joueur).courrir(Math.PI/2); 
	    	if (right) equipe.joueurs.get(joueur).courrir(0); 
	    	if (left) equipe.joueurs.get(joueur).courrir(Math.PI); 
	    	if ((up)&&(right)) equipe.joueurs.get(joueur).courrir(-Math.PI/4); 
	    	if ((up)&&(left)) equipe.joueurs.get(joueur).courrir(-3*Math.PI/4); 
	    	if ((down)&&(right)) equipe.joueurs.get(joueur).courrir(Math.PI/4); 
	    	if ((down)&&(left)) equipe.joueurs.get(joueur).courrir(3*Math.PI/4); 
    	}
    	else equipe.joueurs.get(joueur).arret();
    }
    
    
    public  int getjoueur()
    {
    	return joueur;
    }
    
    public boolean arrow(KeyEvent e){
    	return (e.getKeyCode()==KeyEvent.VK_LEFT)||(e.getKeyCode()==KeyEvent.VK_DOWN)
    		||(e.getKeyCode()==KeyEvent.VK_RIGHT)||(e.getKeyCode()==KeyEvent.VK_UP);
    }
    
    public void setJoueur(){
    	
    	if (Ballon.passe) {
    		equipe.joueurs.get(joueur).arret();
    		equipe.joueurs.get(joueur).accelerer=false;
    		joueur=equipe.joueurProchePasse(joueur, Ballon.getDir(), Ballon.getv());
    		Ballon.passe=false;
    	}
    	
    }
    
    }