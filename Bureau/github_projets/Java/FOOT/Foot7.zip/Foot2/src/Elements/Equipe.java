package Elements;

import java.util.ArrayList;

import contr�le.Jcontr�le;

public class Equipe {
	public ArrayList<Joueur> joueurs = new ArrayList<Joueur>();
	public static int nbJoueurs = 4;
	public boolean utilis�e;
	public Equipe(int camp, boolean b){
		int i;
		utilis�e=b;
		for (i=0;i<nbJoueurs;i++){
			if (camp==Terrain.gauche) joueurs.add(new Joueur(Terrain.dimX*i/nbJoueurs/2,Terrain.dimY/2));
			if (camp==Terrain.droite) joueurs.add(new Joueur(Terrain.dimX-Terrain.dimX*i/nbJoueurs/2,Terrain.dimY/2));
		}
	}
	public void etatSuivant(){
		int i;
		for (i=0;i<Equipe.nbJoueurs;i++){
			if (!possedeBallon()&&(i!=Jcontr�le.joueurSelectionne)) joueurs.get(i).IA.courir();
			if (!possedeBallon()&&(i==Jcontr�le.joueurSelectionne)&&(utilis�e)&&(!Jcontr�le.arrow)) joueurs.get(i).IA.courirVersBallon();
			joueurs.get(i).etatSuivant();
		}
	}
	 
	public ArrayList<Joueur> getEquipe()
	{
		return joueurs;
	}
	
	public boolean possedeBallon(){
		int i;
		for (i=0;i<nbJoueurs;i++){
			if (joueurs.get(i).possedeBallon()) return true;
		}
		return false;
	}
	
	public int joueurBallon(){
		int i,iMin=0;
		double dMin=joueurs.get(0).distBallon();
		for (i=1;i<nbJoueurs;i++){
			if (joueurs.get(i).distBallon()<dMin) {
				dMin=joueurs.get(i).distBallon();
				iMin=i;
			}
		}
		return iMin;
	}
	
	public int joueurBallonP(int j){
		int i,iMin=0;
		double dMin;
		if (j!=0) dMin=joueurs.get(0).distBallonP();
		else dMin=joueurs.get(1).distBallonP();
		for (i=1;i<nbJoueurs;i++){
			if (i!=j){
				if (joueurs.get(i).distBallonP()<dMin) {
					dMin=joueurs.get(i).distBallonP();
					iMin=i;
				}
			}
		}
		return iMin;
	}
	
	public int joueurProchePasse(int j, double thetaB, double vB){
		int i,iMin=0;
		double tMin,t;
		if (j!=0) tMin=joueurs.get(0).tempsPasse(thetaB, vB, joueurs.get(j));
		else tMin=joueurs.get(1).tempsPasse(thetaB, vB, joueurs.get(j));
		for (i=0;i<nbJoueurs;i++){
			if (i!=j){
				t=joueurs.get(i).tempsPasse(thetaB, vB, joueurs.get(j));
				if (t<tMin) {
					tMin=t;
					iMin=i;
				}
			}
		}
		return iMin;
	}
}
