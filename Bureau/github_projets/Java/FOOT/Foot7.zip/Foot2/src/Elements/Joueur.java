package Elements;

import IA.MouvementAuto;
import graph.Screen;

public class Joueur {
	MouvementAuto IA = new MouvementAuto(this);
	public double x;
	public double y;
	public double vMax=200;
	public double vMin=100;
	public double v;
	public boolean accelerer=false;
	public double theta;
	Joueur(int x, int y){
		this.x=x;
		this.y=y;
	}
	
	public void courir(double theta){
		this.theta=theta;
		if (accelerer) v=vMax;
		else v=vMin;
	}
	
	public void arret(){
		v=0;
	}
	
	public boolean possedeBallon(){
		return ((Math.abs(Ballon.x-x)<1)&&(Math.abs(Ballon.y-y)<1));
	}
	
	public void passer(double theta, double v){
		if (possedeBallon()){
		Ballon.x=x+3*Math.cos(theta);
		Ballon.y=y+3*Math.sin(theta);
		Ballon.passe(theta,v);
		}
	}
	
	public void etatSuivant(){
		
		
		if ((x+v*Math.cos(theta)*Screen.dt<Terrain.dimX)&&(x+v*Math.cos(theta)*Screen.dt>0)) this.x+=v*Math.cos(theta)*Screen.dt;
		if ((y+v*Math.sin(theta)*Screen.dt<Terrain.dimY)&&(y+v*Math.sin(theta)*Screen.dt>0)) this.y+=v*Math.sin(theta)*Screen.dt;
		if (possedeBallon()) {
			Ballon.vX=0;
			Ballon.vY=0;
			Ballon.x=x;
			Ballon.y=y;
		}
	}
	
	public double getx()
	{
		return x;
	}
	
	public double gety()
	{
		return y;
	}
	
	public double getv()
	{
		return v;
	}
	public double getDir(){
		return theta;
	}
	
	public double distBallon(){
		return Math.sqrt((x-Ballon.x)*(x-Ballon.x)+(y-Ballon.y)*(y-Ballon.y));
	}
	
	public double distBallonP(){
		return Math.sqrt((x-Ballon.xP)*(x-Ballon.xP)+(y-Ballon.yP)*(y-Ballon.yP));
	}
	
	public double tempsPasse(double thetaB, double vB, Joueur j){
		double alpha, d=Math.sqrt((j.x-x)*(j.x-x)+(j.y-y)*(j.y-y));
		if (Math.abs(j.x-x)>0.01) alpha=Math.atan((j.y-y)/(j.x-x));
		else {
			 if ((j.y-y)<0) alpha=-Math.PI/2;
			 else alpha=Math.PI/2;
		}
		if ((j.x-x)<0) alpha+=Math.PI;
		alpha-=thetaB;
		double l=Math.abs(d*Math.cos(alpha)),h=Math.abs(d*Math.sin(alpha));
		double D=Math.pow(2*l*vB*vB+vMax*vMax,2)-4*(h*h+l*l);
		return Math.sqrt(0.5*(2*l*vB*vB+vMax*vMax-Math.sqrt(D)));
	}
	
}
