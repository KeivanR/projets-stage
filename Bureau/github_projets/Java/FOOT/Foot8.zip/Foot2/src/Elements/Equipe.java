package Elements;

import java.util.ArrayList;

import contr�le.Jcontr�le;

public class Equipe {
	public ArrayList<Joueur> joueurs = new ArrayList<Joueur>();
	public static int nbJoueurs = 12;
	public boolean utilis�e;
	public Equipe(int camp, boolean b){
		utilis�e=b;
			joueurs.add(new Joueur(new Zone("GB")));
			joueurs.add(new Joueur(new Zone("DC")));
			joueurs.add(new Joueur(new Zone("DD")));
			joueurs.add(new Joueur(new Zone("DG")));
			joueurs.add(new Joueur(new Zone("MDF")));
			joueurs.add(new Joueur(new Zone("MC")));
			joueurs.add(new Joueur(new Zone("MD")));
			joueurs.add(new Joueur(new Zone("MG")));
			joueurs.add(new Joueur(new Zone("MO")));
			joueurs.add(new Joueur(new Zone("AC")));
			joueurs.add(new Joueur(new Zone("AG")));
			joueurs.add(new Joueur(new Zone("AD")));
		
		if (camp==Terrain.droite) bordsOppos�s();
	}
	public void etatSuivant(){
		int i;
		for (i=0;i<Equipe.nbJoueurs;i++){
			if (!possedeBallon()&&(!joueurs.get(i).select)) joueurs.get(i).IA.courirVersBallon();
			if (!joueurs.get(i).possedeBallon()&&(joueurs.get(i).select)&&(!Jcontr�le.arrow)) joueurs.get(i).IA.courirVersBallon();
			
			if ((!joueurs.get(i).select)&&(joueurs.get(i).horsZone())) joueurs.get(i).seReplacer();
			joueurs.get(i).etatSuivant();
		}
		
	}
	 
	public ArrayList<Joueur> getEquipe()
	{
		return joueurs;
	}
	
	public boolean possedeBallon(){
		int i;
		for (i=0;i<nbJoueurs;i++){
			if (joueurs.get(i).possedeBallon()) return true;
		}
		return false;
	}
	
	public int joueurBallon(){
		int i,iMin=0;
		double dMin=joueurs.get(0).distBallon();
		for (i=1;i<nbJoueurs;i++){
			if (joueurs.get(i).distBallon()<dMin) {
				dMin=joueurs.get(i).distBallon();
				iMin=i;
			}
		}
		return iMin;
	}
	
	public int joueurBallonP(int j){
		int i,iMin=0;
		double dMin;
		if (j!=0) dMin=joueurs.get(0).distBallonP();
		else dMin=joueurs.get(1).distBallonP();
		for (i=1;i<nbJoueurs;i++){
			if (i!=j){
				if (joueurs.get(i).distBallonP()<dMin) {
					dMin=joueurs.get(i).distBallonP();
					iMin=i;
				}
			}
		}
		return iMin;
	}
	

	public void bordsOppos�s(){
		int i;
		for (i=0;i<nbJoueurs;i++){
			joueurs.get(i).bordsOppos�s();
			
			joueurs.get(i).update(joueurs.get(i).zone);
		}
	}
}
