package Elements;

import IA.MouvementAuto;
import graph.Screen;

public class Joueur {
	MouvementAuto IA = new MouvementAuto(this);
	public double x;
	public double y;
	public double vMax=200;
	public double vMin=100;
	public double v;
	public boolean accelerer=false, select=false;
	public double theta;
	public Zone zone;
	public Joueur(Zone zone){
		this.x=zone.xm/2;
		this.y=zone.ym;
		this.zone=zone;
	}
	
	public void update(Zone zone){
		this.x=Terrain.dimX-zone.xm*0.5;
		this.y=zone.ym;
		this.zone=zone;
	}
	
	public void courir(double theta){
		this.theta=theta;
		if (accelerer) v=vMax;
		else v=vMin;
	}
	
	public void arret(){
		v=0;
	}
	
	public boolean possedeBallon(){
		return ((Math.abs(Ballon.x-x)<1)&&(Math.abs(Ballon.y-y)<1));
	}
	
	public void passer(double theta, double v){
		if (possedeBallon()){
		Ballon.x=x+3*Math.cos(theta);
		Ballon.y=y+3*Math.sin(theta);
		Ballon.passe(theta,v);
		}
	}
	
	public void etatSuivant(){
		
		this.x+=v*Math.cos(theta)*Screen.dt;
		this.y+=v*Math.sin(theta)*Screen.dt;
		if (possedeBallon()) {
			Ballon.vX=0;
			Ballon.vY=0;
			Ballon.x=x;
			Ballon.y=y;
		}
	}
	
	public double getx()
	{
		return x;
	}
	
	public double gety()
	{
		return y;
	}
	
	public double getv()
	{
		return v;
	}
	public double getDir(){
		return theta;
	}
	
	public double distBallon(){
		return Math.sqrt((x-Ballon.x)*(x-Ballon.x)+(y-Ballon.y)*(y-Ballon.y));
	}
	
	public double distBallonP(){
		return Math.sqrt((x-Ballon.xP)*(x-Ballon.xP)+(y-Ballon.yP)*(y-Ballon.yP));
	}
	
	
	
	public boolean horsX(double x){
		return zone.horsX(x);
	}
	
	public boolean horsY(double y){
		return zone.horsY(y);
	}
	
	public boolean horsZone(){
		return zone.horsX(x)||zone.horsY(y);
	}
	
	public void bordsOppos�s(){
		zone.x1=Terrain.dimX-zone.x1;
		zone.x2=Terrain.dimX-zone.x2;
		zone.xm=(double)(zone.x1+zone.x2)/2;
		update(zone);
	}
	
	public void seReplacer(){
		IA.courir(zone.xm, zone.ym);
	}
	
}
