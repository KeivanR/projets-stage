package graph;

public class Refreshscreen {

	public Refreshscreen()
	{
		
	}
}
