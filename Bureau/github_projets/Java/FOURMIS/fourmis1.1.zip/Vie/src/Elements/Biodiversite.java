package Elements;

import java.util.ArrayList;

import InterfaceGraphique.Screen;

public class Biodiversite {
	public ArrayList<EtreVivant> etres = new ArrayList<EtreVivant>();
	public static int nbEtres = 0;
	public int  nbPasses=0;
	public ArrayList<Sucre> graines = new ArrayList<Sucre>();
	public Fourmiliere maison = new Fourmiliere(550,250,50);
	public double qteRapportee=0;
	public Terrain t0;
	public boolean utilis�e;
	public Biodiversite(Terrain t){
		int i;
		t0=t;
		for (i=0;i<nbEtres;i++){
			etres.add(new EtreVivant(t0, maison));
		}
		graines.add(new Sucre(100,100,50));
	}
	public void etatSuivant(int k[]){
		int i,j;
		for (i=0;i<etres.size();i++){
			if (!((mangeGraine(etres.get(i)))&&(!etres.get(i).porteGraine)))  etres.get(i).etatSuivant(); 
			else {
				etres.get(i).tempsGraine++;
				graines.get(graineMangee(etres.get(i))).mangerSucre();
				}
			if (etres.get(i).tempsGraine>100) {etres.get(i).tempsGraine=0; etres.get(i).etatSuivant();etres.get(i).odeur=40;etres.get(i).porteGraine=true;}
			if ((etres.get(i).dansFourmiliere())&&(etres.get(i).porteGraine)) {
				etres.get(i).odeur=10;
				etres.get(i).porteGraine=false;
				qteRapportee+=5/(qteRapportee+1);
				}
		}
		if (k[0]==5) {etres.add(new EtreVivant(t0, maison));k[0]=0;}
	}
	 
	public double distance(EtreVivant e1, EtreVivant e2){
		return Math.sqrt((e1.getx()-e2.getx())*(e1.getx()-e2.getx())+(e1.gety()-e2.gety())*(e1.gety()-e2.gety()));
	}
	public boolean mangeGraine(EtreVivant etre){
		for (int i=0;i<graines.size();i++){
			if (etre.mangeGraine(graines.get(i))) return true;
		}
		return false;
	}
	
	public int graineMangee(EtreVivant etre){
		for (int i=0;i<graines.size();i++){
			if (etre.mangeGraine(graines.get(i))) return i;
		}
		return -2;
	}
	
	public ArrayList<EtreVivant> getEquipe()
	{
		return etres;
	}
	
}
