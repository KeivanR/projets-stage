package Elements;
import InterfaceGraphique.Screen;

import java.util.Random;


public class EtreVivant {
	Random rand = new Random();
	public double x;
	public double y;
	public double v=2;
	public double theta=10*rand.nextDouble();
	public static int taille=5;
	public boolean porteGraine = false;
	public Fourmiliere f;
	public int odeur = 10, tempsGraine=0;
	public Terrain terrInd;
	public EtreVivant(Terrain t, Fourmiliere f){
		this.f=f;
		this.x=f.x+rand.nextInt(f.taille);
		this.y=f.y+rand.nextInt(f.taille);
		terrInd = t;
		//x=1000;
		//y=400;
	}
	
	public void allerVers(EtreVivant e, double precision){
		double thetaDir;
		thetaDir = Math.atan((e.gety()-y)/(e.getx()-x));
		if (x>e.getx()) thetaDir+=Math.PI;
		theta+=(thetaDir-theta)*(rand.nextDouble()-0.48)/5;
		//theta=thetaDir;
	}
	
	public void etatSuivant(){
		int feromPresente=0;
		double thetaProv=0;
		double precision = 5;
		double xFer=x/Terrain.partition+1, yFer=y/Terrain.partition+1;
		if (xFer<2) xFer++;
		if (yFer<2) yFer++;
		if (porteGraine) {
			for (int i=0;i<=precision;i++){
				if (Terrain.feromInd.get((int)(xFer+v*Math.cos(theta+Math.PI/2-Math.PI*(double)i/precision))).get((int)(yFer+v*Math.sin(theta+Math.PI/2-Math.PI*(double)i/precision)))>feromPresente){
					feromPresente=Terrain.feromInd.get((int)(xFer+v*Math.cos(theta+Math.PI/2-Math.PI*(double)i/precision))).get((int)(yFer+v*Math.sin(theta+Math.PI/2-Math.PI*(double)i/precision)));
					thetaProv=theta+Math.PI/2-Math.PI*(double)i/precision;
				}
			}
		if (feromPresente==Terrain.feromInd.get((int)(xFer+v*Math.cos(theta))).get((int)(yFer+v*Math.sin(theta)))) thetaProv=theta;
		if (Terrain.feromNourr.get((int)xFer).get((int)yFer)+odeur<=155)
			Terrain.feromNourr.get((int)xFer).set((int)yFer,Terrain.feromNourr.get((int)xFer).get((int)yFer)+odeur);
		//else Terrain.feromNourr.get((int)xFer).set((int)yFer,155);
		}
		else {
			if (Terrain.feromInd.get((int)xFer).get((int)yFer)+odeur<=155)
				Terrain.feromInd.get((int)xFer).set((int)yFer,Terrain.feromInd.get((int)xFer).get((int)yFer)+odeur);
			//else Terrain.feromInd.get((int)xFer).set((int)yFer,155);
			for (int i=0;i<=precision;i++){
				if (Terrain.feromNourr.get((int)(xFer+v*Math.cos(theta+Math.PI/2-Math.PI*(double)i/precision))).get((int)(yFer+v*Math.sin(theta+Math.PI/2-Math.PI*(double)i/precision)))>feromPresente){
					feromPresente=Terrain.feromNourr.get((int)(xFer+v*Math.cos(theta+Math.PI/2-Math.PI*(double)i/precision))).get((int)(yFer+v*Math.sin(theta+Math.PI/2-Math.PI*(double)i/precision)));
					thetaProv=theta+Math.PI/2-Math.PI*(double)i/precision;
				}
			}
			if (feromPresente==Terrain.feromNourr.get((int)(xFer+v*Math.cos(theta))).get((int)(yFer+v*Math.sin(theta)))) thetaProv=theta;
		}
		if (feromPresente>120) theta=thetaProv; else theta+=(rand.nextDouble()-0.5)/2;
			x+=v*Math.cos(theta);
			y+=v*Math.sin(theta);
		if ((x<10)||(x>Screen.sizeX-100)) {theta=Math.PI-theta;}
		if ((y<10)||(y>Screen.sizeY-100)) {theta=2*Math.PI-theta;}
	}
	
	public boolean mangeGraine(Sucre graine){
		return (x<graine.x+graine.taille)&&(x>graine.x)&&(y<graine.y+graine.taille)&&(y>graine.y);
	}
	
	public boolean dansFourmiliere(){
		return (x<f.x+f.taille)&&(x>f.x)&&(y<f.y+f.taille)&&(y>f.y);
	}
	
	public double getx()
	{
		return x;
	}
	
	public double gety()
	{
		return y;
	}
	
	public double getv()
	{
		return v;
	}
	public double getDir(){
		return theta;
	}
	
	
}
