package Elements;

public class Fourmiliere {
	public static int x,y;
	public static int taille;
	Fourmiliere (int x, int y, int taille){
		this.x = x;
		this.y = y;
		this.taille = taille;
	}
}
