package Elements;

public class Sucre {
	public int x,y;
	public double taille;
	public Sucre (int x, int y, int taille){
		this.x = x;
		this.y = y;
		this.taille = taille;
	}
	public void mangerSucre(){
		taille-=0.1/taille;
	}
	
}
