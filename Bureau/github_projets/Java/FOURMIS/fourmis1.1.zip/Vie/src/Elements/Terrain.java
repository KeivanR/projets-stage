package Elements;

import java.util.ArrayList;

public class Terrain {
	public static int dimX;
	public static int dimY;
	public static int partition=50;
	public static double evaporation = 5;
	public static double  evaporationInd = 1;
	public static double ralentissement;
	public  static ArrayList<ArrayList<Integer>> feromInd = new ArrayList<ArrayList<Integer>>();
	public static ArrayList<ArrayList<Integer>> feromNourr = new ArrayList<ArrayList<Integer>>();
	public Terrain(int dimX, int dimY){
		Terrain.dimX=dimX;
		Terrain.dimY=dimY;
		int i,j;
		for (i=0;i<=dimX/partition+5;i++){
			feromInd.add(i,new ArrayList<Integer>());
			for (j=0;j<=dimY/partition+5;j++){
				feromInd.get(i).add(j, 0);
			}
		}
		for (i=0;i<=dimX/partition+5;i++){
			feromNourr.add(i,new ArrayList<Integer>());
			for (j=0;j<=dimY/partition+5;j++){
				feromNourr.get(i).add(j, 0);
			}
		}
	}
	public  void etatSuivant(){
		int i,j;
		for (i=0;i<dimX/partition;i++){
			for (j=0;j<dimY/partition;j++){
				if (dansFourmiliere((i)*partition-1,(j)*partition-1)){
					//feromInd.get(i-1).set(j-1,255);
					feromInd.get(i).set(j-1,255);
					//feromInd.get(i+1).set(j-1,255);
					feromInd.get(i-1).set(j,255);
					//feromInd.get(i).set(j,255);
					feromInd.get(i+1).set(j,255);
					//feromInd.get(i-1).set(j+1,255);
				    feromInd.get(i).set(j+1,255);
					//feromInd.get(i+1).set(j+1,255);
				}
				if (feromInd.get(i).get(j)>evaporationInd) feromInd.get(i).set(j, feromInd.get(i).get(j)-(int)evaporationInd);
				if (feromNourr.get(i).get(j)>evaporation) feromNourr.get(i).set(j, feromNourr.get(i).get(j)-(int)evaporation);
				else feromNourr.get(i).set(j,0);
			}
		}
	}
	public boolean dansFourmiliere(int x, int y){
		return (x<Fourmiliere.x+Fourmiliere.taille)&&(x>Fourmiliere.x)&&(y<Fourmiliere.y+Fourmiliere.taille)&&(y>Fourmiliere.y);
	}
}
