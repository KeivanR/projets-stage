package Elements;

public class Zone {
	
	public int x1,y1,x2,y2;
	public double xm,ym;
	
	public Zone(String poste){
		int x0=Terrain.dimX;
		int y0=Terrain.dimY;
		xm=(double)(x1+x2)/2;
		ym=(double)(y1+y2)/2;
	}
	
	public void bords(int x1, int y1, int x2, int y2){
		this.y1=y1;
		this.x1=x1;
		this.y2=y2;
		this.x2=x2;
	}
	
	
public boolean horsX(double x){
		if (x2<x1) return (x<x2)||(x>x1);
		return (x>x2)||(x<x1);
	}
	
public boolean horsY(double y){
		return (y<y1)||(y>y2);
	}
}
