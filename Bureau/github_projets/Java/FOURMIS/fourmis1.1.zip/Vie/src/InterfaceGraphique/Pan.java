package InterfaceGraphique;
import javax.swing.JPanel;

import Elements.*;

import java.awt.*;

public class Pan extends JPanel { 
	
	
	Biodiversite groupe;
	public Pan(Biodiversite groupe)
	{
		
		this.groupe=groupe;
		
	}
  public void paintComponent(Graphics g){
	  int t = 2; //Largeur des bandes du terrain
	  int u=EtreVivant.taille;; //taille des joueurs
	  
    //Vous verrez cette phrase chaque fois que la m�thode sera invoqu�e
    Graphics2D g2d = (Graphics2D)g;  
    
    
    g2d.setPaint(Color.WHITE);
    g2d.fillRect(0,0,1200,600);
    int i,j;
    for (i=0;i<Terrain.dimX/Terrain.partition;i++){
			for (j=0;j<Terrain.dimY/Terrain.partition;j++){
				g2d.setPaint(new Color(255-Terrain.feromInd.get(i).get(j),255-Terrain.feromNourr.get(i).get(j),255));
				g2d.fillOval((i-1)*Terrain.partition, (j-1)*Terrain.partition, Terrain.partition, Terrain.partition);
			}
		}
    g2d.setPaint(Color.GRAY); 
    g2d.fillOval(groupe.maison.x,groupe.maison.y,groupe.maison.taille,groupe.maison.taille);
    g2d.setPaint(Color.RED); 
    for (i=0;i<groupe.graines.size();i++){
    g2d.fillRect(groupe.graines.get(i).x,groupe.graines.get(i).y,(int)groupe.graines.get(i).taille,(int)groupe.graines.get(i).taille);
    } 
    for(i=0;i<groupe.etres.size();i++)
      {   
        	  g2d.setPaint(new Color(0,0,0));
              Integer I =(int) (groupe.etres.get(i).getx()-u/2);
        	  Integer J =(int) (groupe.etres.get(i).gety()-u/2);
        	  g2d.fillOval(I,J , u, u);
        	  g2d.fillOval((int)(I-groupe.etres.get(i).taille*Math.cos(groupe.etres.get(i).theta)),(int)(J-groupe.etres.get(i).taille*Math.sin(groupe.etres.get(i).theta)) , u, u);
        	  g2d.fillOval((int)(I-2*groupe.etres.get(i).taille*Math.cos(groupe.etres.get(i).theta)),(int)(J-2*groupe.etres.get(i).taille*Math.sin(groupe.etres.get(i).theta)) , u, u);
        	  if (groupe.etres.get(i).porteGraine) {
        		  g2d.setPaint(Color.RED); 
        	      g2d.fillRect(I,J , u+1, u+1);
        	  }
          }
      
      
      
      g2d.setPaint(Color.RED); 
        g2d.fillOval(groupe.maison.x+(int)groupe.maison.taille,groupe.maison.y, (int)groupe.qteRapportee, (int)groupe.qteRapportee);
      }
          
  
  
  
  public void refreshplayerposition(Biodiversite groupe)
  {
		this.groupe=groupe;
  }
  
}