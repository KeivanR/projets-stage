package InterfaceGraphique;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JPanel;

import Elements.Biodiversite;
import Elements.Sucre;




public class Screen extends JFrame implements MouseListener{

	JPanel pan = new JPanel();
	public static double dt=1;
	public static int sizeX = 1200;
	public static int sizeY = 600;
	Biodiversite equipe;
	public Screen(Biodiversite equipe)
	{
		addMouseListener(this);
	    //D�finit un titre pour notre fen�tre
	    this.setTitle("Screen");
	    //D�finit sa taille : 400 pixels de large et 100 pixels de haut
	    this.setSize(sizeX,sizeY);
	    //Nous demandons maintenant � notre objet de se positionner au centre
	    this.setLocationRelativeTo(null);
	    //Termine le processus lorsqu'on clique sur la croix rouge
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    //Et enfin, la rendre visible        
	    this.setVisible(true);
       //couleur du fond 
	    pan.setBackground(Color.WHITE);
	   //on applique � notre �cran
	    this.equipe=equipe;
	    }
	
	public void modifPan(Pan pan){
		
		this.pan=pan;
		this.setContentPane(pan);
	   
	}
	
	public JPanel getPan(){
		
		return pan;
		
	}
	
	
	 public void refresh(){
		    
		      pan.repaint();  
		      try {
		        Thread.sleep(10);
		      } catch (InterruptedException e) {
		        e.printStackTrace();
		      }
		     
		}
	 
	
	 @Override
		public void mouseClicked(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub
		}
		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub
			int i;
			if (arg0.getButton()==MouseEvent.BUTTON1){
				equipe.graines.add(new Sucre(arg0.getX()-30,arg0.getY()-55,50));
			}
	 
}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
}



