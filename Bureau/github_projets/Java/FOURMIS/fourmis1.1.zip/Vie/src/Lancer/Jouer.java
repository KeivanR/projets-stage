package Lancer;
import Elements.*;
import InterfaceGraphique.*;

public class Jouer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Terrain terrain = new Terrain(Screen.sizeX,Screen.sizeY);
		Biodiversite groupe = new Biodiversite(terrain);
		Screen s0 = new Screen(groupe);
		int maxFourmi = 2000;
		double t=0;
		int k[]={0}; k[0]=0;
		s0.modifPan(new Pan(groupe));
		while(true){
			if (groupe.etres.size()<maxFourmi) k[0]++;
		     //Tout ce que je veux faire
			groupe.etatSuivant(k);
		     
		     //s0.getjccontr�le().getjoueur();
			((Pan) s0.getPan()).refreshplayerposition(groupe);
			s0.refresh();
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//if (t % 10 == 0) Terrain.evaporation=1; else Terrain.evaporation=0;
			terrain.etatSuivant();
			t+=Screen.dt;
			}
	}

}
