import java.util.ArrayList;


class Jouer { 
Fenetre maFenetre = new Fenetre();
boolean collision=false;
Jouer() { 
	maFenetre.setVisible(true);
}
	
	
	


	 
public void repeindre(){	
	 //LANCEMENT
	
			try {
					maFenetre.monUnivers.repaint();
					Thread.sleep(1);    
			}

				
						
			catch (InterruptedException ie) {if (Thread.interrupted()) Thread.currentThread().interrupt();}	
	   } 

public void mouvement(ArrayList<Corps> mesCorps, int precision){
	double G=0.001;
	int i,j;
	double dt=(double)1/(double)precision;
	double xi, yi; 
	double dvXi,dvYi;
	double thetai;
	double dcarrei;
	for (i=0;i<mesCorps.size();i++){
		xi=mesCorps.get(i).x;
		yi=mesCorps.get(i).y;
		dvXi=0; dvYi=0;
		for (j=0;j<mesCorps.size();j++){
			if (j!=i) {
				dcarrei=(mesCorps.get(j).y-yi)*(mesCorps.get(j).y-yi)+(mesCorps.get(j).x-xi)*(mesCorps.get(j).x-xi);
				if (dcarrei>Math.pow(mesCorps.get(i).rayon+mesCorps.get(j).rayon,2)){
					thetai=Math.atan((mesCorps.get(j).y-yi)/(mesCorps.get(j).x-xi));
					if (mesCorps.get(j).x<xi) thetai+=Math.PI;
					dvXi+=G*mesCorps.get(j).masse/dcarrei*dt*Math.cos(thetai);
					dvYi+=G*mesCorps.get(j).masse/dcarrei*dt*Math.sin(thetai);
				}
				else {dvXi=0;dvYi=0;}
			}
		}
		mesCorps.get(i).accelX=dvXi;
		mesCorps.get(i).accelY=dvYi;
		mesCorps.get(i).vitesseX+=dvXi;
		mesCorps.get(i).vitesseY+=dvYi;
		mesCorps.get(i).x+=mesCorps.get(i).vitesseX*dt;
		mesCorps.get(i).y+=mesCorps.get(i).vitesseY*dt;
	}
	
	//collision=(dcarre<Math.pow(monCorps.rayon+monCorps2.rayon,2));
	
}



  public static void main(String[] argv) {
	Jouer monJeu = new Jouer();
	Corps newCorps;
	int i;
	int precision=100;
	double dt=1/precision;
	while (true){
		for (i=0;i<precision;i++){
			monJeu.mouvement(monJeu.maFenetre.monUnivers.mesCorps,precision);
			if (monJeu.maFenetre.pressed) {
				newCorps=monJeu.maFenetre.monUnivers.mesCorps.get(monJeu.maFenetre.monUnivers.mesCorps.size()-1);
				newCorps.x-=newCorps.vitesseX*dt;
				newCorps.y-=newCorps.vitesseY*dt;
				newCorps.vitesseX=0;
				newCorps.vitesseY=0;
				monJeu.maFenetre.monUnivers.mesCorps.set(monJeu.maFenetre.monUnivers.mesCorps.size()-1,newCorps);
			}
		}
		if (monJeu.maFenetre.pressed) {
			monJeu.maFenetre.monUnivers.mesCorps.get(monJeu.maFenetre.monUnivers.mesCorps.size()-1).agrandir(0.1);
			
		}
		monJeu.repeindre();
   }  
}
  }