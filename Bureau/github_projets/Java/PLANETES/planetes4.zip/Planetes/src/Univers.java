import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JPanel;


public class Univers extends JPanel{
	
	private static final long serialVersionUID = 1L;
	public int dimX=1300;
	public int dimY=900;
	public double zoom=1;
	public int zoomX=200;
	public int zoomY=200;
	int i;
	ArrayList<Corps> mesCorps=new ArrayList<Corps>();
	Univers(){
		setBackground(Color.BLACK);
		setPreferredSize(new Dimension(dimX, dimY));
		setVisible(true);
		//	mesCorps.add(new Corps(300,300,10,0,0));
		//	mesCorps.add(new Corps(300,50,10,1,0));
			//mesCorps.add(new Corps(300,550,11,-1,0));
	}
	 public void paintComponent(Graphics g) {
			super.paintComponent(g);
			for (i=0;i<mesCorps.size();i++) {
				mesCorps.get(i).dessiner(g,zoom,zoomX,zoomY);
				if (i==mesCorps.size()-1) mesCorps.get(i).moteur(g,zoom,zoomX,zoomY);
				mesCorps.get(i).fleche(g,zoom,zoomX,zoomY);
				mesCorps.get(i).accel(g,zoom,zoomX,zoomY);}
			//if (mesCorps.size()>0) mesCorps.get(mesCorps.size()-1).fleche(g);
		 }
}
