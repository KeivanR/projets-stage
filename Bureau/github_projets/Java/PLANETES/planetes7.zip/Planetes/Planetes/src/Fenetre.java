

import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Fenetre extends JFrame implements MouseListener,KeyListener,MouseMotionListener{
	static final long serialVersionUID = 1;
	boolean pressed=false;
	boolean gauche=false,droite=false,haut=false,bas=false;
	double vX, vY, theta=0;
	int moteur=0;
	double vRefX=0, vRefY=0;
	public int iRef=-1;
	int zoomX, zoomY;
	Univers monUnivers;
	JLabel titre = new JLabel("Plan�tes");
	JPanel indications = new JPanel();
	public int dimX=1300;
	public int dimY=900;
	public Fenetre(){
		addMouseListener(this);
		addMouseMotionListener(this);
		addKeyListener(this);
		monUnivers=new Univers(dimX,dimY);
		indications.setLayout(new BorderLayout());
		indications.add(titre);
		add(indications, BorderLayout.NORTH);
		add(monUnivers, BorderLayout.CENTER);
		setDefaultLookAndFeelDecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
	}
	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
	}
	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		monUnivers.mesCorps.add(new Corps((arg0.getX()-monUnivers.zoomX)/monUnivers.zoom+monUnivers.zoomX,(arg0.getY()-monUnivers.zoomY)/monUnivers.zoom+monUnivers.zoomY,0,0,0));
		pressed=true;
	}
	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		pressed=false;
	}
	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		int i;
		vX=monUnivers.mesCorps.get(monUnivers.mesCorps.size()-1).vitesseX;
		vY=monUnivers.mesCorps.get(monUnivers.mesCorps.size()-1).vitesseY;
		if (arg0.getKeyCode()==KeyEvent.VK_DOWN) {moteur=-1;}
		if (arg0.getKeyCode()==KeyEvent.VK_UP) {moteur=1;}
		if (arg0.getKeyCode()==KeyEvent.VK_LEFT) {theta-=0.1;}
		if (arg0.getKeyCode()==KeyEvent.VK_RIGHT) {theta+=0.1;}
		monUnivers.mesCorps.get(monUnivers.mesCorps.size()-1).thetaMoteur=theta;
		monUnivers.mesCorps.get(monUnivers.mesCorps.size()-1).vitesseX=vX;
		monUnivers.mesCorps.get(monUnivers.mesCorps.size()-1).vitesseY=vY;
		if (arg0.getKeyChar()=='z') {monUnivers.zoomX=zoomX;monUnivers.zoom+=0.1;}
		if (arg0.getKeyChar()=='d') {monUnivers.zoomY=zoomY;monUnivers.zoom-=0.1;}
		if ((arg0.getKeyCode()>=KeyEvent.VK_NUMPAD0)&&(arg0.getKeyCode()<=KeyEvent.VK_NUMPAD9)&&(arg0.getKeyCode()-KeyEvent.VK_NUMPAD1<monUnivers.mesCorps.size())){;
			for (i=0;i<monUnivers.mesCorps.size();i++) {
				iRef=arg0.getKeyCode()-KeyEvent.VK_NUMPAD1;
			}
		}
	}
	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseDragged(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		zoomX=e.getX();
		zoomY=e.getY();
		if (e.getX()<50)  gauche=true; else gauche=false;
		if (e.getX()>dimX-20) droite=true; else droite=false;
		if (e.getY()<80) haut=true; else haut=false;
		if (e.getY()>dimY-150) bas=true; else bas=false;
	}
	
	
	
}