import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;


public class Fruits extends JFrame {
	
	//OPTIONS
	public int tailleFruit=10;
	public int vitamines=3;
	public int dimX, dimY;
	public Color couleurF=Color.GREEN;
	static final long serialVersionUID = 1;
	int i;
	public double fruitX=-10, fruitY=-10;
	public boolean fruitPresent=false, fruitPourri=false;
	public Fruits(int dimX, int dimY) {
			this.dimX=dimX;
			this.dimY=dimY;
			NouvellePosFruit();
			}
	
	public void NouvellePosFruit(){
		fruitX=tailleFruit+(dimX-3*tailleFruit)*Math.random();
		fruitY=tailleFruit+(dimY-3*tailleFruit)*Math.random();
	}
	public void NouveauFruit(Graphics g){
		g.setColor(couleurF);
		g.fillRect((int)fruitX,(int)fruitY,tailleFruit,tailleFruit);  
		
	}
	public void AncienFruit(Graphics g){
		g.setColor(Color.ORANGE);
		g.fillRect((int)fruitX,(int)fruitY,tailleFruit,tailleFruit);  
		
	}
	
	
}