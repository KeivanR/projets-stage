import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;


class Jouer { 
Fenetre maFenetre = new Fenetre();
Jouer() { 
	maFenetre.setVisible(true);
}
	
	
	

public void parois(){	
	//PAROIS
	int i;
	
	try {
	maFenetre.monArdoise.MonSerpent.paroisY=0;
	for (i=0;i<=maFenetre.dimX;i++) {
		maFenetre.monArdoise.MonSerpent.paroisX=i;
		maFenetre.monArdoise.repaint(maFenetre.monArdoise.MonSerpent.paroisX,maFenetre.monArdoise.MonSerpent.paroisY,1,1);
		Thread.sleep(1);  
	}
	maFenetre.monArdoise.MonSerpent.paroisY=maFenetre.dimY-1;
	for (i=0;i<=maFenetre.dimX;i++) {
		maFenetre.monArdoise.MonSerpent.paroisX=i;
		maFenetre.monArdoise.repaint(maFenetre.monArdoise.MonSerpent.paroisX,maFenetre.monArdoise.MonSerpent.paroisY,1,1);
		Thread.sleep(1);  
	}
	maFenetre.monArdoise.MonSerpent.paroisX=0;
	for (i=0;i<=maFenetre.dimY;i++) {
		maFenetre.monArdoise.MonSerpent.paroisY=i;
		maFenetre.monArdoise.repaint(maFenetre.monArdoise.MonSerpent.paroisX,maFenetre.monArdoise.MonSerpent.paroisY,1,1);
		Thread.sleep(1);  
	}
	maFenetre.monArdoise.MonSerpent.paroisX=maFenetre.dimX-1;
	for (i=0;i<=maFenetre.dimY;i++) {
		maFenetre.monArdoise.MonSerpent.paroisY=i;
		maFenetre.monArdoise.repaint(maFenetre.monArdoise.MonSerpent.paroisX,maFenetre.monArdoise.MonSerpent.paroisY,1,1);
		Thread.sleep(1);  
	}
	maFenetre.monArdoise.MonSerpent.paroisPasFaite=false;
	}
	catch (InterruptedException ie) {if (Thread.interrupted()) Thread.currentThread().interrupt();}	
}	
	//CINEMATIQUE INITIALISATION DU SERPENT
public void cinematique(Serpent MonSerpent){	
	int i;
	int tailleS=MonSerpent.tailleSerpent;
	 for (i=0;i<MonSerpent.morceauxX.size();i++){
			
			try {
				MonSerpent.x=(int)(double)MonSerpent.morceauxX.get(i);
				MonSerpent.y=(int)(double)MonSerpent.morceauxY.get(i);
				maFenetre.monArdoise.repaint(MonSerpent.x,MonSerpent.y,tailleS,tailleS);
				Thread.sleep(1000);    	
			}
			catch (InterruptedException ie) {if (Thread.interrupted()) Thread.currentThread().interrupt();}	
	 }
}	 
	 
public void lancement(Serpent MonSerpent, double[] sec, Dechets mesDechets, int[] iDechet){	
	 //LANCEMENT
	
	double temps=1000/MonSerpent.vitesse;
	if (maFenetre.monArdoise.mode2J) temps= (int) ((double)(temps)/2);
	int tailleS=MonSerpent.tailleSerpent, tailleF=Serpent.MonFruit.tailleFruit;
	int i;
		 
		 MonSerpent.x=(int)(double)MonSerpent.morceauxX.get(0);
		 MonSerpent.y=(int)(double)MonSerpent.morceauxY.get(0);
			try {
					maFenetre.monArdoise.repaint((int)(double)MonSerpent.morceauxX.get(MonSerpent.morceauxX.size()-1),(int)(double)MonSerpent.morceauxY.get(MonSerpent.morceauxX.size()-1),tailleS,tailleS);
					Thread.sleep(1);    
					

				
						if (!MonSerpent.sortDuDechet){
							for (i=0;i<MonSerpent.mesDechets.dechetsX.size();i++){
								if (MonSerpent.mangeSonDechet(i)){
									iDechet[0]=i;
									MonSerpent.sortDuDechet=true;
								}
							}
						}
						if ((MonSerpent.sortDuDechet)&&(!MonSerpent.mangeSonDechet(iDechet[0]))){
							Serpent.MonFruit.fruitPresent=true;
							Serpent.MonFruit.fruitPourri=true;
							maFenetre.monArdoise.xAD=MonSerpent.mesDechets.dechetsX.get(iDechet[0]);
							maFenetre.monArdoise.yAD=MonSerpent.mesDechets.dechetsY.get(iDechet[0]);
							maFenetre.monArdoise.repaint(maFenetre.monArdoise.xAD,maFenetre.monArdoise.yAD,tailleF,tailleF);
							Thread.sleep(1);
							Serpent.MonFruit.fruitPourri=false;
							Serpent.MonFruit.fruitPresent=false;
							MonSerpent.sortDuDechet=false;
						}
					
					
					if ((MonSerpent.Mange())&&(!MonSerpent.sortDuFruit)) {
						for (i=0;i<Serpent.MonFruit.vitamines;i++) {MonSerpent.Grandir();}
						 Thread.sleep(150); 
						 MonSerpent.sortDuFruit=true;
						 sec[0]+=152;
				    }
					
					
					if ((!MonSerpent.Mange())&&(MonSerpent.sortDuFruit)) {
						
							MonSerpent.mesDechets.dechetsX.add(MonSerpent.mesDechets.dechetsX.size(),(int)Serpent.MonFruit.fruitX);
							MonSerpent.mesDechets.dechetsY.add(MonSerpent.mesDechets.dechetsY.size(),(int)Serpent.MonFruit.fruitY);
						
						Serpent.MonFruit.fruitPresent=true;
						Serpent.MonFruit.fruitPourri=true;
						maFenetre.monArdoise.xAD=(int)Serpent.MonFruit.fruitX;
						maFenetre.monArdoise.yAD=(int)Serpent.MonFruit.fruitY;
						maFenetre.monArdoise.repaint(maFenetre.monArdoise.xAD,maFenetre.monArdoise.yAD,tailleF,tailleF);
						Thread.sleep(1);
						Serpent.MonFruit.fruitPourri=false;
						Serpent.MonFruit.fruitPresent=false;
					
						Serpent.MonFruit.NouvellePosFruit();
						maFenetre.monArdoise.repaint((int)Serpent.MonFruit.fruitX,(int)Serpent.MonFruit.fruitY,tailleF,tailleF);
						
						Thread.sleep(1); 
						MonSerpent.sortDuFruit=false;
						
					}
					else {MonSerpent.Avancer();}
					MonSerpent.x=(int)(double)MonSerpent.morceauxX.get(0);
			 		MonSerpent.y=(int)(double)MonSerpent.morceauxY.get(0);
			 		maFenetre.monArdoise.repaint(MonSerpent.x,MonSerpent.y,tailleS,tailleS);
			 		if (temps<1) Thread.sleep(1); else Thread.sleep((int)temps); 
				
			}
			catch (InterruptedException ie) {if (Thread.interrupted()) Thread.currentThread().interrupt();}	
			sec[0]+=1+temps;
	   } 

public void resultat(Serpent MonSerpent, int[] h, int[] m, int[] s, int[] r, double[] sec){
	
		MonSerpent.Perdu();
		sec[0]=sec[0]/1000;
		h[0]=(int)(sec[0]/3600);
		m[0]=(int)((sec[0]-3600*h[0])/60);
		s[0]=(int)(sec[0]-3600*h[0]-60*m[0]);
		r[0]=(int)((sec[0]-3600*h[0]-60*m[0]-s[0])*100);
		System.out.println("\nDur�e : "+h[0]+":"+ m[0] + ":" + s[0] + ":" + r[0] +
		"\nVitesse : " +(double)((MonSerpent.morceauxX.size()-3)/sec[0])+" pommes/sec");
		
		
	
}

public void enregistrer(File fichier, int[] h, int[] m, int[] s, int[] r, double[] sec){
//ENREGISTRER LE SCORE
	try {
	    final FileWriter writer = new FileWriter(fichier,true);
	    BufferedWriter bw =new BufferedWriter(writer);
	    try {
	        bw.write("\r\n"+h+":"+m+":"+s+":"+r+";"+(double)((maFenetre.monArdoise.MonSerpent.morceauxX.size()-3)/sec[0])+";"+
	        		10*(maFenetre.monArdoise.MonSerpent.morceauxX.size()-3)+";"
	        		+ maFenetre.monArdoise.MonSerpent.vitesse +";"
					+ maFenetre.monArdoise.MonSerpent.sansBord+";"
					+ maFenetre.monArdoise.MonSerpent.dimX +"x"+ maFenetre.monArdoise.MonSerpent.dimY+";"
	        		+ maFenetre.monArdoise.MonSerpent.dechetsToxiques+"\r\n" );
	    } 
	    finally {bw.close();}
	} 
	catch (Exception e) {System.out.println("Impossible de creer le fichier");}
}


  public static void main(String[] argv) {
	  int[] h=new int[1],m=new int[1],s=new int[1],r=new int[1];
	  double[] sec=new double[1];
	  sec[0]=0;
	final File fichier =new File("C:/Users/Keivan/Documents/scores.txt"); 
	int numPartie = 0;
	while (numPartie<50) {
		numPartie++;
	Jouer monJeu = new Jouer();
	
	monJeu.parois();
	
	while ((!monJeu.maFenetre.monArdoise.MonSerpent.Collision(monJeu.maFenetre.monArdoise.mode2J,monJeu.maFenetre.monArdoise.MonSerpent,monJeu.maFenetre.monArdoise.MonSerpent2))&&(!monJeu.maFenetre.monArdoise.MonSerpent2.Collision(monJeu.maFenetre.monArdoise.mode2J,monJeu.maFenetre.monArdoise.MonSerpent2,monJeu.maFenetre.monArdoise.MonSerpent))){
		monJeu.lancement(monJeu.maFenetre.monArdoise.MonSerpent,sec,monJeu.maFenetre.monArdoise.MonSerpent2.mesDechets,monJeu.maFenetre.monArdoise.MonSerpent.iDechet);
		if (monJeu.maFenetre.monArdoise.mode2J) monJeu.lancement(monJeu.maFenetre.monArdoise.MonSerpent2,sec,monJeu.maFenetre.monArdoise.MonSerpent.mesDechets,monJeu.maFenetre.monArdoise.MonSerpent2.iDechet);
	}
	if (monJeu.maFenetre.monArdoise.mode2J){
		if (monJeu.maFenetre.monArdoise.MonSerpent.Collision(monJeu.maFenetre.monArdoise.mode2J,monJeu.maFenetre.monArdoise.MonSerpent,monJeu.maFenetre.monArdoise.MonSerpent2)){
			System.out.println("Le Serpent noir a gagn� !");
		}
		else System.out.println("Le Serpent rouge a gagn� !");
	}
	System.out.println("Serpent rouge : \n");
	monJeu.resultat(monJeu.maFenetre.monArdoise.MonSerpent,h,m,s,r,sec);
	if (monJeu.maFenetre.monArdoise.mode2J){
	System.out.println("Serpent noir : \n");
	monJeu.resultat(monJeu.maFenetre.monArdoise.MonSerpent2,h,m,s,r,sec);
	}
	monJeu.enregistrer(fichier,h,m,s,r,sec);
	}
	
	
   }  
 
}