

import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Fenetre extends JFrame implements MouseListener,KeyListener{
	static final long serialVersionUID = 1;
	boolean pressed=false;
	double vX, vY, theta;
	Univers monUnivers;
	JLabel titre = new JLabel("Plan�tes");
	JPanel indications = new JPanel();
	public int dimX=400;
	public int dimY=300;
	public Fenetre(){
		addMouseListener(this);
		addKeyListener(this);
		monUnivers=new Univers();
		monUnivers.dimX=dimX;
		monUnivers.dimY=dimY;
		indications.setLayout(new BorderLayout());
		indications.add(titre);
		add(indications, BorderLayout.NORTH);
		add(monUnivers, BorderLayout.CENTER);
		setDefaultLookAndFeelDecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
	}
	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
		monUnivers.mesCorps.add(new Corps(arg0.getX(),arg0.getY(),0,0,0));
		pressed=true;
	}
	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		pressed=false;
	}
	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		vX=monUnivers.mesCorps.get(monUnivers.mesCorps.size()-1).vitesseX;
		vY=monUnivers.mesCorps.get(monUnivers.mesCorps.size()-1).vitesseY;
		theta=Math.atan(vY/vX); if (vX<0) theta+=Math.PI;
		if (arg0.getKeyCode()==KeyEvent.VK_DOWN) {
			vX-=0.02*Math.cos(theta);
			vY-=0.02*Math.sin(theta);
		}
		if (arg0.getKeyCode()==KeyEvent.VK_UP) {vX+=0.1*Math.cos(theta);vY+=0.1*Math.sin(theta);}
		if (arg0.getKeyCode()==KeyEvent.VK_LEFT) {vX=Math.sqrt(vX*vX+vY*vY)*Math.cos(theta-0.1);vY=Math.sqrt(vX*vX+vY*vY)*Math.sin(theta-0.1);}
		if (arg0.getKeyCode()==KeyEvent.VK_RIGHT) {vX=Math.sqrt(vX*vX+vY*vY)*Math.cos(theta+0.1);vY=Math.sqrt(vX*vX+vY*vY)*Math.sin(theta+0.1);}
		monUnivers.mesCorps.get(monUnivers.mesCorps.size()-1).vitesseX=vX;
		monUnivers.mesCorps.get(monUnivers.mesCorps.size()-1).vitesseY=vY;
	}
	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}