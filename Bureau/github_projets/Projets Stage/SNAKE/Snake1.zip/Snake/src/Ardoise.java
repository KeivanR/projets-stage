import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;


public class Ardoise extends JPanel{
	
	private static final long serialVersionUID = 1L;
	public int dimX=400;
	public int dimY=300;
	public int xAD,yAD;
	public boolean mode2J=false;
	Serpent MonSerpent = new Serpent(50,50,dimX,dimY,1,Color.RED,Color.RED);
	Serpent MonSerpent2 = new Serpent(dimX-50,dimY-50,dimX,dimY,-1,Color.BLACK,Color.BLACK);
	Ardoise(){
		Serpent.MonFruit.NouvellePosFruit();
		setBackground(Color.WHITE);
		setPreferredSize(new Dimension(dimX, dimY));
		setVisible(true);
		
	}
	 public void paintComponent(Graphics g) {
			super.paintComponent(g);
			MonSerpent.dessinerMorceau(g);
			if (mode2J) MonSerpent2.dessinerMorceau(g);
			if (!Serpent.MonFruit.fruitPresent)  Serpent.MonFruit.NouveauFruit(g); 
			if ((Serpent.MonFruit.fruitPourri)&&(!mode2J)) Serpent.MonFruit.AncienFruit(g);
			if ((Serpent.MonFruit.fruitPourri)&&(mode2J)) {
				if ((!MonSerpent.Mange())&&(MonSerpent.sortDuFruit)|| (MonSerpent.sortDuDechet)) MonSerpent.mesDechets.AncienFruit(g,xAD,yAD);
				if ((!MonSerpent2.Mange())&&(MonSerpent2.sortDuFruit)|| (MonSerpent2.sortDuDechet)) MonSerpent2.mesDechets.AncienFruit(g,xAD,yAD);
			}
			if (MonSerpent.paroisPasFaite) MonSerpent.Parois(g);
		 }
}
