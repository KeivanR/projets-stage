

import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Fenetre extends JFrame implements KeyListener{
	static final long serialVersionUID = 1;
	Ardoise monArdoise = new Ardoise();
	JLabel titre = new JLabel("Snake Choundeh");
	JPanel indications = new JPanel();
	public int dimX=400;
	public int dimY=300;
	double dt=Math.PI/15;
	public boolean nouveau=true, controleVitesse=true;
	public Fenetre(){
		monArdoise.dimX=dimX;
		monArdoise.dimY=dimY;
		indications.setLayout(new BorderLayout());
		indications.add(titre);
		add(indications, BorderLayout.NORTH);
		add(monArdoise, BorderLayout.CENTER);
		addKeyListener (this);
		setDefaultLookAndFeelDecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
	}
	
	public void keyPressed(KeyEvent evt){
			if (!nouveau){
				//Serpent1
				if (evt.getKeyCode() == KeyEvent.VK_RIGHT) {monArdoise.MonSerpent.dirX=1; monArdoise.MonSerpent.dirY=0;}
				if (evt.getKeyCode() == KeyEvent.VK_UP) {monArdoise.MonSerpent.dirX=0; monArdoise.MonSerpent.dirY=-1;}
				if (evt.getKeyCode() == KeyEvent.VK_LEFT) {monArdoise.MonSerpent.dirX=-1; monArdoise.MonSerpent.dirY=0;}
				if (evt.getKeyCode() == KeyEvent.VK_DOWN) {monArdoise.MonSerpent.dirX=0; monArdoise.MonSerpent.dirY=1;}
				//Serpent2
				if (evt.getKeyCode() == KeyEvent.VK_D) {monArdoise.MonSerpent2.dirX=1; monArdoise.MonSerpent2.dirY=0;}
				if (evt.getKeyCode() == KeyEvent.VK_Z) {monArdoise.MonSerpent2.dirX=0; monArdoise.MonSerpent2.dirY=-1;}
				if (evt.getKeyCode() == KeyEvent.VK_Q) {monArdoise.MonSerpent2.dirX=-1; monArdoise.MonSerpent2.dirY=0;}
				if (evt.getKeyCode() == KeyEvent.VK_S) {monArdoise.MonSerpent2.dirX=0; monArdoise.MonSerpent2.dirY=1;}
			}
			else {
				if (evt.getKeyCode() == KeyEvent.VK_RIGHT) {
					monArdoise.MonSerpent.t+=dt;
					monArdoise.MonSerpent.dirX=Math.cos(monArdoise.MonSerpent.t); monArdoise.MonSerpent.dirY=Math.sin(monArdoise.MonSerpent.t);
					}
				if (evt.getKeyCode() == KeyEvent.VK_LEFT) {
					monArdoise.MonSerpent.t-=dt;
					monArdoise.MonSerpent.dirX=Math.cos(monArdoise.MonSerpent.t); monArdoise.MonSerpent.dirY=Math.sin(monArdoise.MonSerpent.t);
					}
				if (evt.getKeyCode() == KeyEvent.VK_D) {
					monArdoise.MonSerpent2.t+=dt;
					monArdoise.MonSerpent2.dirX=Math.cos(monArdoise.MonSerpent2.t); monArdoise.MonSerpent2.dirY=Math.sin(monArdoise.MonSerpent2.t);
					}
				if (evt.getKeyCode() == KeyEvent.VK_Q) {
					monArdoise.MonSerpent2.t-=dt;
					monArdoise.MonSerpent2.dirX=Math.cos(monArdoise.MonSerpent2.t); monArdoise.MonSerpent2.dirY=Math.sin(monArdoise.MonSerpent2.t);
					}
				if (controleVitesse){
					if (evt.getKeyCode() == KeyEvent.VK_UP) {
						monArdoise.MonSerpent.vitesse+=5;
						}
					if ((evt.getKeyCode() == KeyEvent.VK_DOWN)&&(monArdoise.MonSerpent.vitesse!=5)) {
						monArdoise.MonSerpent.vitesse-=5;
						}
	
					if (evt.getKeyCode() == KeyEvent.VK_Z) {
						monArdoise.MonSerpent2.vitesse+=5;
						}
					if ((evt.getKeyCode() == KeyEvent.VK_S)&&(monArdoise.MonSerpent2.vitesse!=5)) {
						monArdoise.MonSerpent2.vitesse-=5;
						}
				}
			}
	}

	 public void keyReleased(KeyEvent evt){} 

	 public void keyTyped(KeyEvent evt) {
		 
	 }
	
}