import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JFrame;


public class Serpent extends JFrame {
	
	//OPTIONS
	public int tailleSerpent=3;
	public int dimX, dimY;
	double vitesse=50; //vitesse = 1,2 ou 3
	boolean sansBord=true, dechetsToxiques=false;
	public Color couleurS, couleurF, couleurD;
	static final long serialVersionUID = 1;
	int i;
	public int[] iDechet= new int[1];
	boolean paroisPasFaite=true;
	public int paroisX=0, paroisY=0;
	public double  dirX, dirY=0;
	public ArrayList<Double> morceauxX = new ArrayList<Double>();
	public ArrayList<Double> morceauxY = new ArrayList<Double>();
	public int x=50,y=50;
	public double t=0;
	static Fruits MonFruit;
	Dechets mesDechets;
	public boolean sortDuFruit=false, sortDuDechet=false;
	public boolean Mange(){
		if ((morceauxX.get(0)>MonFruit.fruitX-tailleSerpent)&&(morceauxX.get(0)<MonFruit.fruitX+MonFruit.tailleFruit)&&(morceauxY.get(0)>MonFruit.fruitY-tailleSerpent)&&(morceauxY.get(0)<MonFruit.fruitY+MonFruit.tailleFruit)) return true;
		else return false;
	}
	public Serpent(double posInitX, double posInitY, int dimX, int dimY, int dirX, Color couleurS, Color couleurD) {
			this.couleurD=couleurD;
			this.couleurS=couleurS;
			this.dirX=dirX;
			this.dimX=dimX;
			this.dimY=dimY;
			MonFruit = new Fruits(dimX, dimY);
			mesDechets= new Dechets(couleurD);
			morceauxX.add(0,posInitX);
			morceauxY.add(0,posInitY);
			morceauxX.add(1,posInitX-tailleSerpent);
			morceauxY.add(1,posInitY);
			morceauxX.add(2,posInitX-2*tailleSerpent);
			morceauxY.add(2,posInitY);
			x=(int)posInitX;
			y=(int)posInitY;
			}
	public void Avancer(){
		morceauxX.set(0,morceauxX.get(0)+tailleSerpent*dirX);
		morceauxY.set(0,morceauxY.get(0)+tailleSerpent*dirY);
		if (sansBord){
			if (morceauxX.get(0)<1) morceauxX.set(0, (double)(dimX-tailleSerpent-1));
			if (morceauxX.get(0)>dimX-tailleSerpent-1) morceauxX.set(0, 1.0);
			if (morceauxY.get(0)<1) morceauxY.set(0, (double)(dimY-tailleSerpent-1));
			if (morceauxY.get(0)>dimY-tailleSerpent-1) morceauxY.set(0, 1.0);
		}
		for (i=morceauxX.size()-1;i>0;i--){
			morceauxX.set(i,morceauxX.get(i-1));
			morceauxY.set(i,morceauxY.get(i-1));
		}
	}
	public void Grandir(){
		double tempX=morceauxX.get(morceauxX.size()-1),tempY=morceauxY.get(morceauxX.size()-1);
		Avancer();
		morceauxX.add(morceauxX.size(),tempX);
		morceauxY.add(morceauxY.size(),tempY);
	}
	public void dessinerMorceau(Graphics g) {
			g.setColor(couleurS);	 
			g.fillRect(x,y,tailleSerpent,tailleSerpent);   
		}
	public void Parois(Graphics g) {
		g.setColor(Color.BLACK);
		g.fillRect(paroisX,paroisY,1,1);  
	}
	boolean seMordLaQueue(int i){
		return (morceauxX.get(0)>morceauxX.get(i)-tailleSerpent)&&(morceauxX.get(0)<morceauxX.get(i)+tailleSerpent)&&(morceauxY.get(0)>morceauxY.get(i)-tailleSerpent)&&(morceauxY.get(0)<morceauxY.get(i)+tailleSerpent);
	}
	boolean mangeDechet(int i){
		return (morceauxX.get(0)>MonFruit.dechetsX.get(i)-tailleSerpent)&&(morceauxX.get(0)<MonFruit.dechetsX.get(i)+MonFruit.tailleFruit)&&(morceauxY.get(0)>MonFruit.dechetsY.get(i)-tailleSerpent)&&(morceauxY.get(0)<MonFruit.dechetsY.get(i)+MonFruit.tailleFruit);
		}
	boolean mangeDechetAutre(int i, Serpent MonSerpent2){
		return (morceauxX.get(0)>MonSerpent2.mesDechets.dechetsX.get(i)-tailleSerpent)&&(morceauxX.get(0)<MonSerpent2.mesDechets.dechetsX.get(i)+MonSerpent2.mesDechets.tailleFruit)&&(morceauxY.get(0)>MonSerpent2.mesDechets.dechetsY.get(i)-tailleSerpent)&&(morceauxY.get(0)<MonSerpent2.mesDechets.dechetsY.get(i)+MonSerpent2.mesDechets.tailleFruit);
	}
	boolean mangeSonDechet(int i){
		return (morceauxX.get(0)>mesDechets.dechetsX.get(i)-tailleSerpent)&&(morceauxX.get(0)<mesDechets.dechetsX.get(i)+mesDechets.tailleFruit)&&(morceauxY.get(0)>mesDechets.dechetsY.get(i)-tailleSerpent)&&(morceauxY.get(0)<mesDechets.dechetsY.get(i)+mesDechets.tailleFruit);
	}
	boolean mordQueueAutre(int i, Serpent MonSerpent2){
		return (morceauxX.get(0)>MonSerpent2.morceauxX.get(i)-tailleSerpent)&&(morceauxX.get(0)<MonSerpent2.morceauxX.get(i)+tailleSerpent)&&(morceauxY.get(0)>MonSerpent2.morceauxY.get(i)-tailleSerpent)&&(morceauxY.get(0)<MonSerpent2.morceauxY.get(i)+tailleSerpent);
	}
	public boolean Collision(boolean mode2J, Serpent MonSerpent2){
		int oui=0;
	
		boolean toucheLeMur=(morceauxX.get(0)<1)||(morceauxX.get(0)>dimX-tailleSerpent-1)||(morceauxY.get(0)<1)||(morceauxY.get(0)>dimY-tailleSerpent-1);
		if (toucheLeMur) {oui=1;System.out.println("1");}
		for (i=4;i<morceauxX.size()-1;i++){
			if (seMordLaQueue(i)) {oui=1;System.out.println("2 , "+i);}
		}
		if ((dechetsToxiques)&&(!mode2J)) {
			for (i=0;i<MonFruit.dechetsX.size();i++){
				if (mangeDechet(i)) {oui=1;System.out.println("dechet "+i);}
			}
		}
		if (mode2J){
			for (i=0;i<MonSerpent2.mesDechets.dechetsX.size();i++){
				if (mangeDechetAutre(i,MonSerpent2)) {oui=1;System.out.println("4");}
			}
			for (i=2;i<MonSerpent2.morceauxX.size()-1;i++){
				if (mordQueueAutre(i,MonSerpent2)) {oui=1;System.out.println("5");}
			}
		}
		return oui==1;
	}
	
	public void Perdu() {
		System.out.println( "\nNiveau : " + vitesse 
				+ "\nMode sans bord: " + sansBord
				+ "\nTaille : " + dimX +"x"+ dimY 
				+ "\n\nSCORE : "+10*(morceauxX.size()-3));
	}
	
	
	
}
