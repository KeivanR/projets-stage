import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;


public class Ardoise2 extends JPanel{
	
	private static final long serialVersionUID = 1L;
	public int dimX=400;
	public int dimY=300;
	public int xAD,yAD;
	public boolean mode2J=false;
	Serpent2 MonSerpent = new Serpent2(50,50,dimX,dimY,1,Color.RED,Color.RED);
	Serpent2 MonSerpent2 = new Serpent2(dimX-50,dimY-50,dimX,dimY,-1,Color.BLACK,Color.BLACK);
	Ardoise2(){
		if (mode2J){
			MonSerpent = new Serpent2(50,50,dimX,dimY,1,Color.RED,Color.RED);
			MonSerpent2 = new Serpent2(dimX-50,dimY-50,dimX,dimY,-1,Color.BLACK,Color.BLACK);
		}
		else MonSerpent = new Serpent2(50,50,dimX,dimY,1,Color.RED,Color.YELLOW);
		Serpent2.MonFruit.NouvellePosFruit();
		setBackground(Color.WHITE);
		setPreferredSize(new Dimension(dimX, dimY));
		setVisible(true);
		
	}
	 public void paintComponent(Graphics g) {
			super.paintComponent(g);
			MonSerpent.dessinerMorceau(g);
			if (mode2J) MonSerpent2.dessinerMorceau(g);
			if (!Serpent2.MonFruit.fruitPresent)  Serpent2.MonFruit.NouveauFruit(g); 
			if (Serpent2.MonFruit.fruitPourri) {
				if ((!MonSerpent.Mange())&&(MonSerpent.sortDuFruit)|| (MonSerpent.sortDuDechet)) MonSerpent.mesDechets.AncienFruit(g,xAD,yAD);
				if ((mode2J)&&(!MonSerpent2.Mange())&&(MonSerpent2.sortDuFruit)|| (MonSerpent2.sortDuDechet)) MonSerpent2.mesDechets.AncienFruit(g,xAD,yAD);
			}
			if (MonSerpent.paroisPasFaite) MonSerpent.Parois(g);
		 }
}
