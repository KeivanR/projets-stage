import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JFrame;


public class Dechets2 extends JFrame {
	
	//OPTIONS
	public int tailleFruit=15;
	public Color couleurD;
	static final long serialVersionUID = 1;
	int i;
	public ArrayList<Integer> dechetsX = new ArrayList<Integer>();
	public ArrayList<Integer> dechetsY = new ArrayList<Integer>();
	public Dechets2(Color couleur) {
			this.couleurD=couleur;
	}
	
	public void AncienFruit(Graphics g, int x, int y){
		g.setColor(couleurD);
		g.fillRect(x,y,tailleFruit,tailleFruit);  
		
	}
	
	
}